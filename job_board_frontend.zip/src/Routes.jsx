import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Signup from './components/Signup';
import Dashboard from './components/Dashboard';
import Login from './components/Login'; // Import the Login component

const Routes = () => {
    return (
        <Router>
            <Switch>
                <Route path="/signup" component={Signup} />
                <Route path="/dashboard" component={Dashboard} />
                <Route path="/login" component={Login} />
            </Switch>
        </Router>
    );
};

export default Routes;
