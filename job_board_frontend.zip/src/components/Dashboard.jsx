import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { login } from '../actions/index';

const Login = () => {
    const dispatch = useDispatch();


    return (
        <div>
            <h2>Dashboard</h2>
            <span onClick={() =>localStorage.removeItem('token')}>LogOut</span>
        </div>
    );
};

export default Login;
