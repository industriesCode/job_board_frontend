import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { login } from '../actions/index';
import {Navigate} from "react-router-dom";

const Login = () => {
    const dispatch = useDispatch();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = () => {
        dispatch(login(username, password));
    };

    return (
        <div>
            <h2>Login</h2>
            <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <button onClick={handleLogin}>Login</button>
            <h5>Don't have an account? <a href='/signUp'>Sign Up</a></h5>
        </div>
    );
};

export default Login;
