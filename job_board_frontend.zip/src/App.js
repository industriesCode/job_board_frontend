import './App.css';
import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from "./components/Dashboard";
import Signup from "./components/Signup";
import Login from "./components/Login";

function App() {
    const token = localStorage.getItem('token');

    return (
        <BrowserRouter>
            <Routes>
                {!token && <Navigate to="/login" />}
                {token ? (
                    <Route path="/" element={<Dashboard />} />
                ) : (
                    <>
                        <Route path="/signUp" element={<Signup />} />
                        {/*<Route path="/signIn" element={<Navigate to="/login" />} />*/}
                        <Route path="/login" element={<Login />} />
                    </>
                )}
            </Routes>
        </BrowserRouter>
    );
}

export default App;