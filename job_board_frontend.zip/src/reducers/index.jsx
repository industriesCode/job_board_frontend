import { combineReducers } from 'redux';

const rootReducer = (state = {}, action) => {
    return state;
};

export default rootReducer;
